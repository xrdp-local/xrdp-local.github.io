SYSTEM_CONFIG_FILE = "/etc/xrdp_local_session.json"
